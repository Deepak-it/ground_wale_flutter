import 'package:flutter/material.dart';

import 'sports_neo_onboarding_flow.dart';

class SportsNeoDashboardScreen extends StatefulWidget {
  const SportsNeoDashboardScreen({super.key});

  @override
  State<SportsNeoDashboardScreen> createState() =>
      _SportsNeoDashboardScreenState();
}

class _SportsNeoDashboardScreenState extends State<SportsNeoDashboardScreen> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  static const List<_SlideData> _slides = <_SlideData>[
    _SlideData(
      titleWhite: 'Book Ground',
      titleBlue: 'instantly',
      subtitle:
          'Find nearby sports grounds, compare slots and play without waiting,',
      imageUrl:
          'https://api.builder.io/api/v1/image/assets/TEMP/d190aa0a4d049d10d8999a93139dd237a7479cb1?width=1536',
      buttonLabel: 'Next',
    ),
    _SlideData(
      titleWhite: 'Manage Teams',
      titleBlue: '& Matches',
      subtitle:
          'Create squads, track players and schedule matches effortlessly.',
      imageUrl:
          'https://api.builder.io/api/v1/image/assets/TEMP/33f208be3b6bca10406b9df31a99c11945a53e85?width=1662',
      buttonLabel: 'Next',
    ),
    _SlideData(
      titleWhite: 'Train Smarter',
      titleBlue: 'Every Day',
      subtitle: 'Join academies, track attendance and improve your games.',
      imageUrl:
          'https://api.builder.io/api/v1/image/assets/TEMP/8a2a00e8b8ad1a1035e51e47a7b48bdb5041f40f?width=1660',
      buttonLabel: 'Get Started',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _goNext(BuildContext context) {
    if (_currentIndex < _slides.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
      );
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const SportsNeoWelcomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0F1E),
      body: SafeArea(
        child: PageView.builder(
          controller: _pageController,
          onPageChanged: (int value) => setState(() => _currentIndex = value),
          itemCount: _slides.length,
          itemBuilder: (BuildContext context, int index) {
            final _SlideData slide = _slides[index];
            return _SportsNeoSlide(
              slide: slide,
              currentIndex: index,
              totalCount: _slides.length,
              onSkip: () {
                _pageController.animateToPage(
                  _slides.length - 1,
                  duration: const Duration(milliseconds: 280),
                  curve: Curves.easeOutCubic,
                );
              },
              onNext: () => _goNext(context),
            );
          },
        ),
      ),
    );
  }
}

class _SportsNeoSlide extends StatelessWidget {
  const _SportsNeoSlide({
    required this.slide,
    required this.currentIndex,
    required this.totalCount,
    required this.onSkip,
    required this.onNext,
  });

  final _SlideData slide;
  final int currentIndex;
  final int totalCount;
  final VoidCallback onSkip;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Expanded(
          flex: 62,
          child: Stack(
            children: <Widget>[
              Positioned.fill(
                child: Image.network(
                  slide.imageUrl,
                  fit: BoxFit.cover,
                  errorBuilder:
                      (
                        BuildContext context,
                        Object error,
                        StackTrace? stackTrace,
                      ) {
                        return Container(
                          color: const Color(0xFF141B33),
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.image_not_supported_outlined,
                            color: Color(0xFFDBE7FF),
                            size: 44,
                          ),
                        );
                      },
                ),
              ),
              Positioned(top: 18, left: 18, child: _BrandMark(onTap: onSkip)),
              Positioned(
                top: 42,
                right: 24,
                child: TextButton(
                  onPressed: onSkip,
                  child: const Text(
                    'Skip',
                    style: TextStyle(
                      color: Color(0xFFDBE7FF),
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          flex: 38,
          child: Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xFF09082F),
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            padding: const EdgeInsets.fromLTRB(24, 30, 24, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                RichText(
                  text: TextSpan(
                    style: const TextStyle(
                      fontSize: 38,
                      fontWeight: FontWeight.w700,
                      height: 1.08,
                      color: Colors.white,
                    ),
                    children: <TextSpan>[
                      TextSpan(text: '${slide.titleWhite}\n'),
                      TextSpan(
                        text: slide.titleBlue,
                        style: const TextStyle(color: Color(0xFF2563EB)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  slide.subtitle,
                  style: const TextStyle(
                    color: Color(0xCCFFFFFF),
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    height: 1.35,
                  ),
                ),
                const Spacer(),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Row(
                        children: List<Widget>.generate(totalCount, (
                          int index,
                        ) {
                          final bool active = index == currentIndex;
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            margin: EdgeInsets.only(
                              right: index == totalCount - 1 ? 0 : 6,
                            ),
                            width: active ? 28 : 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: active
                                  ? const Color(0xFF2563EB)
                                  : const Color(0xFFC3D6FF),
                              borderRadius: BorderRadius.circular(12),
                            ),
                          );
                        }),
                      ),
                    ),
                    SizedBox(
                      height: 44,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF2563EB),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          elevation: 0,
                        ),
                        onPressed: onNext,
                        child: Text(
                          slide.buttonLabel,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark({required this.onTap});

  final VoidCallback onTap;

  static const List<String> _logoCandidates = <String>[
    'assets/images/sport-neo-logo.png',
    'assets/images/sport-neo-logo-refined.png',
    'assets/images/sports_neo_logo.png',
    'assets/images/sport_neo_logo.png',
  ];

  Widget _buildLogo(int index) {
    return Image.asset(
      _logoCandidates[index],
      width: 80,
      height: 71,
      fit: BoxFit.contain,
      errorBuilder:
          (BuildContext context, Object error, StackTrace? stackTrace) {
            if (index < _logoCandidates.length - 1) {
              return _buildLogo(index + 1);
            }

            return const Icon(Icons.sports, color: Colors.white, size: 32);
          },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTap, child: _buildLogo(0));
  }
}

class _SlideData {
  const _SlideData({
    required this.titleWhite,
    required this.titleBlue,
    required this.subtitle,
    required this.imageUrl,
    required this.buttonLabel,
  });

  final String titleWhite;
  final String titleBlue;
  final String subtitle;
  final String imageUrl;
  final String buttonLabel;
}
